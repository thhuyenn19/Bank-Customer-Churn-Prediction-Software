-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bankchurn
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `user_name` varchar(20) DEFAULT NULL,
  `pass_word` varchar(20) DEFAULT NULL,
  `employee_id` varchar(20) DEFAULT NULL,
  `employee_name` varchar(50) DEFAULT NULL,
  `phone` varchar(12) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES ('minhan723','an@1234','RD001','Pham Minh An','0903456723','minhan723@gmail.com'),('nhattan234','tan@1234','RD002','Tran Nhat Tan','0908901234','nhattan234@gmail.com'),('thuminh811','minh@1234','RD003','Nguyen Thi Thu Minh','0868347811','thuminh811@gmail.com'),('nhatminh456','minh@1234','RD004','Le Hoang Nhat Minh','0974123456','nhatminh456@gmail.com'),('vankien101','kien@1234','RD005','Pham Van Kien','0933789101','vankien101@gmail.com'),('thutram123','tram@1234','RD006','Thai Thi Thu Tram','0917890123','thutram123@gmail.com'),('minhthao333','thao@1234','RD007','Le Nguyen Minh Thao','0378444333','minhthao333@gmail.com'),('thanhhuyen234','huyen@1234','RD008','Nguyen Tran Thanh Huyen','0978901234','thanhhuyen234@gmail.com'),('quynhnhu567','nhu@1234','RD009','Vu Quynh Nhu','0861234567','quynhnhu567@gmail.com'),('tuyetnhung789','nhung@1234','RD010','Pham Tuyet Nhung','0913456789','tuyetnhung789@gmail.com'),('thanhthao567','thao@1234','RD011','Lam Thanh Thao','0901234567','thanhthao567@gmail.com'),('congdanh789','danh@1234','RD012','Le Tran Cong Danh','0793456789','congdanh789@gmail.com'),('ngoctrinh901','trinh@1234','RD013','Tran Thi Ngoc Trinh','0925678901','ngoctrinh901@gmail.com'),('thienthuc345','thuc@1234','RD014','Dam Thien Thuc','0829012345','thienthuc345@gmail.com'),('minhquy789','quy@1234','RD015','Nguyen Tien Minh Quy','0923456789','minhquy789@gmail.com'),('dactai567','tai@1234','RD016','Ta Le Dac Tai','0961234567','dactai567@gmail.com'),('thanhkhoa543','khoa@1234','RD017','Nguyen Thanh Khoa','0709876543','thanhkhoa543@gmail.com'),('chikien901','kien@1234','RD018','Chau Chi Kien','0935678901','chikien901@gmail.com'),('phuongtram901','tram@1234','RD019','Nguyen Phuong Tram','0845678901','phuongtram901@gmail.com'),('nhuphuong012','phuong@1234','RD020','Le Thi Nhu Phuong','0946789012','nhuphuong012@gmail.com'),('thungan432','ngan@1234','RD021','Tran Thu Ngan','0908765432','thungan432@gmail.com'),('ngocbich543','bich@1234','RD022','Huynh Thi Ngoc Bich','0919876543','ngocbich543@gmail.com'),('baotran789','tran@1234','RD023','Do Nhat Bao Tran','0923456789','baotran789@gmail.com'),('tuanminh012','minh@1234','RD024','Le Tuan Minh','0796789012','tuanminh012@gmail.com'),('minhnhat678','nhat@1234','RD025','Tran Minh Nhat','0962345678','minhnhat678@gmail.com');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-22 13:27:03
